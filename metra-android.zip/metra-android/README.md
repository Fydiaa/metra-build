# METRA — Android metronome prototype

Interfaccia italiana, Kotlin, Jetpack Compose e Material 3. Progetto sorgente pensato per essere aperto in Android Studio.

## Caratteristiche incluse

- BPM da **15 a 500**, variazione ±1/±5, slider e inserimento numerico diretto.
- Tap tempo basato su `elapsedRealtimeNanos`, mediana e filtro degli intervalli anomali. Un singolo intervallo lungo non dimezza accidentalmente il tempo; due intervalli consecutivi coerenti permettono di acquisire un nuovo BPM. La soglia di pausa si adatta anche al tempo lento di 15 BPM. Test unitari inclusi.
- Firme preimpostate (2/4, 3/4, 4/4, 5/4, 6/8, 7/8, 9/8, 12/8) e firma personalizzabile con numeratore 1–16 e denominatore 2/4/8/16.
- Pattern per battuta modificabile individualmente: normale → accento → mute. Il pattern si adatta quando cambia il numeratore.
- Suddivisioni 1×, 2×, 3× e 4×.
- Cinque timbri selezionabili e anteprima: Wood, Deep, Classic, Block e Soft.
- Mute globale che lascia attivo il clock e l'indicatore visivo, volume master regolabile; palette Amber, Jade, Violet, Ice e Coral.
- Preset nominati salvabili/richiamabili/eliminabili (fino a 20) e preferenze principali salvate localmente sul dispositivo.
- Motore audio PCM a 48 kHz che pianifica i colpi sulla timeline dei campioni; la grafica è separata dalla generazione del ritmo.

## Importazione

1. Installa Android Studio aggiornato e i componenti SDK Android API 36.
2. Apri la cartella `metra-android` come progetto Gradle. Il piccolo launcher incluso scarica Gradle 8.13 al primo avvio se non è già disponibile; serve quindi una connessione Internet durante la prima sincronizzazione.
3. Attendi la risoluzione delle dipendenze e avvia la configurazione `app` su un dispositivo/emulatore Android 8.0 (API 26) o successivo.

## Audio — nota di trasparenza

I dieci WAV inclusi sono asset PCM mono a 48 kHz progettati per il prototipo mediante sintesi di transienti e risonanze smorzate. **Non sono registrazioni microfoniche di un blocco di legno o di un metronomo meccanico reale.** Il codice supporta WAV PCM a 16 bit e i campioni possono essere sostituiti con registrazioni acustiche autorizzate mantenendo gli stessi nomi di file. Per un prodotto da pubblicare, la resa va ascoltata e misurata su dispositivi fisici e con cuffie/altoparlanti diversi.

## Verifiche e limiti

I test unitari del tap tempo coprono tempo stabile, intervallo saltato, cambio intenzionale di tempo, doppio tocco, timestamp non monotoni, limiti BPM e pausa lunga, inclusa una battuta saltata a 15 BPM. Gli asset WAV vengono generati deterministicamente e sono PCM mono a 48 kHz/16 bit. In questo ambiente non è disponibile il download della distribuzione Gradle e la rete di build è bloccata: non è stato quindi possibile eseguire qui `testDebugUnitTest`/`assembleDebug` né provare un APK su dispositivo. La build remota deve essere verificata prima di installare. Nessun controllo statico può garantire assenza assoluta di bug o certificare la latenza audio su ogni modello Android.
