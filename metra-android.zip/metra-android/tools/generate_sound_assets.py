"""Create deterministic, sound-designed PCM click samples for the Metra prototype.
These are synthesized sample assets, not recordings of a physical wooden block.
"""
import math, random, wave, struct
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / 'app/src/main/assets/sounds'
OUT.mkdir(parents=True, exist_ok=True)
SR = 48000
SOUNDS = {
    'wood':    {'modes': [(390, .54, .060), (760, .31, .036), (1280, .15, .021)], 'noise': .24, 'dur': .19, 'low': 190, 'attack': .0032},
    'deep':    {'modes': [(215, .62, .105), (480, .31, .068), (880, .12, .032)], 'noise': .18, 'dur': .30, 'low': 115, 'attack': .0044},
    'classic': {'modes': [(520, .31, .052), (1420, .40, .024), (2350, .20, .012)], 'noise': .40, 'dur': .115, 'low': 285, 'attack': .0016},
    'block':   {'modes': [(650, .46, .050), (1750, .33, .022), (2900, .18, .011)], 'noise': .36, 'dur': .14, 'low': 310, 'attack': .0018},
    'soft':    {'modes': [(300, .50, .085), (610, .25, .056), (1040, .10, .032)], 'noise': .10, 'dur': .24, 'low': 145, 'attack': .008},
}

def make_sample(name, cfg, accent=False):
    rng = random.Random(4051 + sum(map(ord, name)) + (1 if accent else 0))
    dur = cfg['dur'] * (1.0 if not accent else 1.06)
    count = int(SR * dur)
    out = []
    # Slightly different modal excitation for accented beats; avoid mere volume-only duplicates.
    accent_shift = 1.025 if accent else 1.0
    noise_amt = cfg['noise'] * (1.10 if accent else 1.0)
    for i in range(count):
        t = i / SR
        attack = 1.0 - math.exp(-t / cfg['attack'])
        body = 0.0
        for j, (freq, amp, decay) in enumerate(cfg['modes']):
            f = freq * (accent_shift if j == 0 else (1.008 if accent and j == 1 else 1.0))
            phase = 0.08 * j
            # Each mode has a quick attack and its own damped decay, similar to a struck resonant object.
            body += amp * math.sin(2 * math.pi * f * t + phase) * math.exp(-t / decay)
        low = 0.12 * math.sin(2 * math.pi * cfg['low'] * t) * math.exp(-t / (cfg['dur'] * 0.42))
        n = rng.uniform(-1.0, 1.0) * noise_amt * math.exp(-t / (cfg['attack'] * 2.7))
        # A short, rounded transient with a little filtered-noise character.
        sample = attack * body + low + n
        # Gentle transient shaping and a smooth fade avoid clicks at file boundaries.
        if t < 0.001:
            sample *= t / 0.001
        fade_start = dur * 0.78
        if t > fade_start:
            sample *= max(0.0, (dur - t) / (dur - fade_start)) ** 1.5
        out.append(sample)
    peak = max(abs(x) for x in out) or 1.0
    scale = 0.73 / peak
    # Accent masters are a little louder and have slightly more upper body.
    if accent:
        scale *= 0.98
    pcm = [max(-32768, min(32767, int(x * scale * 32767))) for x in out]
    filename = OUT / (name + ('_accent' if accent else '') + '.wav')
    with wave.open(str(filename), 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(SR)
        wf.writeframes(b''.join(struct.pack('<h', x) for x in pcm))
    return filename

for name, cfg in SOUNDS.items():
    make_sample(name, cfg, False)
    make_sample(name, cfg, True)
print('Created', len(list(OUT.glob('*.wav'))), 'PCM sample assets in', OUT)
