package org.gradle.wrapper;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Minimal bootstrapper for this project when the official Gradle wrapper JAR is unavailable. */
public final class GradleWrapperMain {
    public static void main(String[] args) throws Exception {
        Path project = Paths.get(System.getProperty("gradle.wrapper.project-dir", System.getProperty("user.dir"))).toAbsolutePath();
        Path propertiesPath = project.resolve("gradle/wrapper/gradle-wrapper.properties");
        Properties properties = new Properties();
        try (InputStream in = new FileInputStream(propertiesPath.toFile())) { properties.load(in); }
        String distributionUrl = properties.getProperty("distributionUrl");
        if (distributionUrl == null || distributionUrl.trim().isEmpty()) {
            throw new IllegalStateException("distributionUrl missing in " + propertiesPath);
        }
        String filename = new File(new URL(distributionUrl).getPath()).getName();
        String distributionName = filename.replaceFirst("-(bin|all)\\.zip$", "");
        String flavor = filename.endsWith("-all.zip") ? "all" : "bin";
        Path cacheRoot = Paths.get(System.getProperty("user.home"), ".gradle", "wrapper", "dists",
                distributionName + "-" + flavor, "metra-bootstrap");
        Path gradleHome = cacheRoot.resolve(distributionName);
        String executableName = isWindows() ? "gradle.bat" : "gradle";
        Path executable = gradleHome.resolve("bin").resolve(executableName);

        if (!Files.isRegularFile(executable)) {
            Files.createDirectories(cacheRoot);
            Path archive = cacheRoot.resolve(filename);
            Path extracted = cacheRoot.resolve("unpacked-temp");
            deleteRecursively(extracted.toFile());
            Files.createDirectories(extracted);
            System.out.println("Downloading Gradle " + distributionName.replace("gradle-", "") + " (first run only)...");
            HttpURLConnection connection = (HttpURLConnection) new URL(distributionUrl).openConnection();
            connection.setConnectTimeout(30000);
            connection.setReadTimeout(60000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", "Metra-Gradle-Bootstrap/1.0");
            try (InputStream in = new BufferedInputStream(connection.getInputStream());
                 BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(archive.toFile()))) {
                byte[] buffer = new byte[65536];
                int read;
                while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            } finally {
                connection.disconnect();
            }
            try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(new FileInputStream(archive.toFile())))) {
                ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    Path target = extracted.resolve(entry.getName()).normalize();
                    if (!target.startsWith(extracted)) throw new IllegalStateException("Unsafe ZIP entry: " + entry.getName());
                    if (entry.isDirectory()) {
                        Files.createDirectories(target);
                    } else {
                        Files.createDirectories(target.getParent());
                        try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(target.toFile()))) {
                            byte[] buffer = new byte[65536];
                            int read;
                            while ((read = zip.read(buffer)) != -1) out.write(buffer, 0, read);
                        }
                    }
                    zip.closeEntry();
                }
            }
            Path unpackedGradle = extracted.resolve(distributionName);
            if (!Files.isDirectory(unpackedGradle)) {
                throw new IllegalStateException("Gradle archive did not contain expected folder " + distributionName);
            }
            deleteRecursively(gradleHome.toFile());
            Files.move(unpackedGradle, gradleHome, StandardCopyOption.REPLACE_EXISTING);
            deleteRecursively(extracted.toFile());
            archive.toFile().delete();
            if (!isWindows()) executable.toFile().setExecutable(true, false);
        }

        java.util.List<String> command = new java.util.ArrayList<String>();
        if (isWindows()) {
            command.add("cmd.exe"); command.add("/c"); command.add("\"" + executable.toString() + "\"");
        } else {
            command.add(executable.toString());
        }
        for (String arg : args) command.add(arg);
        Process process = new ProcessBuilder(command).directory(project.toFile()).inheritIO().start();
        System.exit(process.waitFor());
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }

    private static void deleteRecursively(File file) throws Exception {
        if (!file.exists()) return;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteRecursively(child);
        if (!file.delete()) throw new IllegalStateException("Could not remove " + file);
    }
}
