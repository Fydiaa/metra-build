package com.metra.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import com.metra.studio.audio.MetronomeAudioEngine
import com.metra.studio.ui.MetraScreen

class MainActivity : ComponentActivity() {
    private var activeBeat by mutableIntStateOf(-1)
    private var audioFailureCount by mutableIntStateOf(0)
    private lateinit var audioEngine: MetronomeAudioEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 17, 19)
        window.navigationBarColor = android.graphics.Color.rgb(16, 17, 19)
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = false
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = false
        audioEngine = MetronomeAudioEngine(
            assets = assets,
            onBeat = { activeBeat = it },
            onAudioFailure = { audioFailureCount += 1 }
        )
        setContent {
            MetraScreen(
                engine = audioEngine,
                currentBeat = activeBeat,
                audioFailureCount = audioFailureCount,
                onCurrentBeatReset = { activeBeat = -1 }
            )
        }
    }

    override fun onDestroy() {
        if (::audioEngine.isInitialized) audioEngine.close()
        super.onDestroy()
    }
}
