package com.metra.studio.audio

import android.content.res.AssetManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.os.Process
import com.metra.studio.AudioConfig
import com.metra.studio.safeMasterVolume
import java.io.Closeable
import kotlin.math.max
import kotlin.math.min

/**
 * Sample-clock metronome renderer. It continuously feeds PCM frames to AudioTrack and schedules
 * all beat events on the audio frame timeline, rather than relying on UI timers or coroutines.
 */
class MetronomeAudioEngine(
    private val assets: AssetManager,
    private val onBeat: (Int) -> Unit,
    private val onAudioFailure: () -> Unit = {}
) : Closeable {
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var config = AudioConfig(96, 4, 1, "wood", false, intArrayOf(1, 0, 0, 0))
    @Volatile private var running = false
    @Volatile private var sessionId = 0
    @Volatile private var activeTrack: AudioTrack? = null
    private var renderThread: Thread? = null
    private val soundBank: Map<String, ToneSamples> by lazy { loadSoundBank() }
    private val SUPPORTED_SOUNDS = setOf("wood", "deep", "classic", "block", "soft")
    private var previewTrack: AudioTrack? = null
    private var previewRelease: Runnable? = null

    fun updateConfig(newConfig: AudioConfig) {
        config = newConfig.copy(
            bpm = newConfig.bpm.coerceIn(15, 500),
            beatsPerBar = newConfig.beatsPerBar.coerceIn(1, 16),
            subdivisions = newConfig.subdivisions.coerceIn(1, 4),
            beatPattern = newConfig.beatPattern.map { it.coerceIn(0, 2) }.toIntArray(),
            masterVolume = safeMasterVolume(newConfig.masterVolume),
            soundId = newConfig.soundId.takeIf { it in SUPPORTED_SOUNDS } ?: "wood"
        )
    }

    @Synchronized
    fun start() {
        if (running && renderThread?.isAlive == true) return
        val generation = sessionId + 1
        sessionId = generation
        running = true
        renderThread = Thread({ renderLoop(generation) }, "Metra-AudioClock").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    @Synchronized
    fun stop() {
        running = false
        sessionId += 1
        val stoppingThread = renderThread
        try { stoppingThread?.join(900L) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        if (renderThread === stoppingThread) renderThread = null
    }

    /** Plays a short isolated preview of the selected sound; playback does not alter the clock. */
    @Synchronized
    fun preview(soundId: String) {
        val samples = try { soundBank[soundId] ?: soundBank.getValue("wood") } catch (_: Exception) { return }
        try {
            previewRelease?.let(mainHandler::removeCallbacks)
            previewTrack?.let { old ->
                try { old.pause(); old.flush(); old.release() } catch (_: Exception) { }
            }
            val pcm = samples.accent
            val minBytes = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .build()
                )
                .setBufferSizeInBytes(max(max(minBytes, pcm.size * 2), 2048))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.setVolume(config.masterVolume.coerceIn(0f, 1f))
            val written = track.write(pcm, 0, pcm.size, AudioTrack.WRITE_BLOCKING)
            if (written > 0) {
                previewTrack = track
                track.play()
                val release = Runnable {
                    try { track.stop() } catch (_: Exception) { }
                    try { track.release() } catch (_: Exception) { }
                    if (previewTrack === track) previewTrack = null
                    previewRelease = null
                }
                previewRelease = release
                mainHandler.postDelayed(release, (pcm.size * 1000L / SAMPLE_RATE) + 120L)
            } else {
                track.release()
            }
        } catch (_: Exception) {
            // A preview should never interrupt or crash the metronome UI.
        }
    }

    private fun renderLoop(generation: Int) {
        var track: AudioTrack? = null
        var failure: Throwable? = null
        try {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val bank = soundBank
            val minBuffer = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuffer <= 0) {
                failure = IllegalStateException("AudioTrack returned an invalid buffer size: $minBuffer")
                return
            }
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .build()
                )
                .setBufferSizeInBytes(max(minBuffer, CHUNK_FRAMES * 2 * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            activeTrack = track
            track.play()

            val output = ShortArray(CHUNK_FRAMES)
            val voices = arrayOfNulls<Voice>(VOICE_SLOTS)
            var frameClock = 0L
            var nextEventFrame = 0.0
            var lastTempo = -1
            var lastSubdivisionCount = -1
            var beatIndex = 0
            var subdivisionStep = 0
            var styleForCurrentBeat = 0

            while (isSessionActive(generation)) {
                for (frame in output.indices) {
                    val cfg = config
                    if (frameClock.toDouble() >= nextEventFrame) {
                        val tempoChanged = cfg.bpm != lastTempo || cfg.subdivisions != lastSubdivisionCount
                        if (tempoChanged) {
                            nextEventFrame = frameClock.toDouble()
                            lastTempo = cfg.bpm
                            lastSubdivisionCount = cfg.subdivisions
                            if (subdivisionStep >= cfg.subdivisions) subdivisionStep = 0
                        }

                        if (subdivisionStep == 0) {
                            beatIndex %= cfg.beatsPerBar
                            styleForCurrentBeat = cfg.beatPattern.getOrElse(beatIndex) { if (beatIndex == 0) 1 else 0 }
                            val beatForUi = beatIndex
                            // Align the visual pulse with queued audio, rather than with render time.
                            val playbackHead = track.playbackHeadPosition.toLong() and 0xffffffffL
                            val pendingFrames = max(0L, frameClock - playbackHead) + CHUNK_FRAMES
                            val callbackDelayMs = (pendingFrames * 1000L / SAMPLE_RATE).coerceAtMost(1000L)
                            mainHandler.postDelayed({ if (isSessionActive(generation)) onBeat(beatForUi) }, callbackDelayMs)
                            if (!cfg.muteAll && styleForCurrentBeat != 2) {
                                val tone = bank[cfg.soundId] ?: bank.getValue("wood")
                                val accent = styleForCurrentBeat == 1
                                addVoice(voices, if (accent) tone.accent else tone.normal, if (accent) 0.96f else 0.68f, cfg.masterVolume)
                            }
                            beatIndex = (beatIndex + 1) % cfg.beatsPerBar
                        } else if (!cfg.muteAll && styleForCurrentBeat != 2) {
                            val tone = bank[cfg.soundId] ?: bank.getValue("wood")
                            addVoice(voices, tone.normal, 0.30f, cfg.masterVolume)
                        }

                        subdivisionStep = (subdivisionStep + 1) % cfg.subdivisions
                        nextEventFrame += SAMPLE_RATE.toDouble() * 60.0 / cfg.bpm / cfg.subdivisions
                    }

                    var mixed = 0.0
                    for (voiceIndex in voices.indices) {
                        val voice = voices[voiceIndex] ?: continue
                        if (voice.position >= voice.pcm.size) {
                            voices[voiceIndex] = null
                        } else {
                            mixed += voice.pcm[voice.position].toDouble() * voice.gain
                            voice.position++
                        }
                    }
                    output[frame] = mixed.toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                    frameClock++
                }
                var offset = 0
                while (offset < output.size && isSessionActive(generation)) {
                    val written = track.write(output, offset, output.size - offset, AudioTrack.WRITE_BLOCKING)
                    if (written <= 0) {
                        if (isSessionActive(generation)) {
                            failure = IllegalStateException("AudioTrack.write failed: $written")
                            running = false
                        }
                        offset = output.size
                        break
                    }
                    offset += written
                }
            }
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        } catch (error: Exception) {
            // Fail closed: audio errors should not bring down the application, but report them.
            if (sessionId == generation) failure = error
        } finally {
            try { track?.pause() } catch (_: Exception) { }
            try { track?.flush() } catch (_: Exception) { }
            try { track?.release() } catch (_: Exception) { }
            if (activeTrack === track) activeTrack = null
            if (sessionId == generation) running = false
            val reportedFailure = failure
            if (reportedFailure != null && sessionId == generation) {
                mainHandler.post { if (sessionId == generation) onAudioFailure() }
            }
        }
    }

    private fun isSessionActive(generation: Int): Boolean = running && sessionId == generation

    private fun addVoice(voices: Array<Voice?>, pcm: ShortArray, sampleGain: Float, master: Float) {
        val gain = sampleGain * master.coerceIn(0f, 1f)
        val slot = voices.indexOfFirst { it == null || it.position >= it.pcm.size }
        if (slot >= 0) voices[slot] = Voice(pcm, 0, gain)
    }

    private fun loadSoundBank(): Map<String, ToneSamples> {
        val result = linkedMapOf<String, ToneSamples>()
        for (id in listOf("wood", "deep", "classic", "block", "soft")) {
            result[id] = ToneSamples(
                normal = readPcmAsset("sounds/$id.wav"),
                accent = readPcmAsset("sounds/${id}_accent.wav")
            )
        }
        return result
    }

    private fun readPcmAsset(path: String): ShortArray {
        val bytes = assets.open(path).use { it.readBytes() }
        var offset = 12
        var dataOffset = -1
        var dataLength = 0
        while (offset + 8 <= bytes.size) {
            val id = String(bytes, offset, 4, Charsets.US_ASCII)
            val size = (bytes[offset + 4].toInt() and 0xff) or
                ((bytes[offset + 5].toInt() and 0xff) shl 8) or
                ((bytes[offset + 6].toInt() and 0xff) shl 16) or
                ((bytes[offset + 7].toInt() and 0xff) shl 24)
            if (id == "data") {
                dataOffset = offset + 8
                dataLength = min(size, bytes.size - dataOffset)
                break
            }
            offset += 8 + size + (size and 1)
        }
        require(dataOffset >= 0 && dataLength > 0 && dataLength % 2 == 0) { "Invalid PCM asset: $path" }
        val shortCount = dataLength / 2
        return ShortArray(shortCount) { i ->
            val pos = dataOffset + i * 2
            (((bytes[pos + 1].toInt() shl 8) or (bytes[pos].toInt() and 0xff))).toShort()
        }
    }

    override fun close() {
        stop()
        synchronized(this) {
            previewRelease?.let(mainHandler::removeCallbacks)
            previewRelease = null
            previewTrack?.let { try { it.stop() } catch (_: Exception) { }; try { it.release() } catch (_: Exception) { } }
            previewTrack = null
        }
    }

    private data class ToneSamples(val normal: ShortArray, val accent: ShortArray)
    private data class Voice(val pcm: ShortArray, var position: Int, val gain: Float)

    companion object {
        private const val SAMPLE_RATE = 48_000
        private const val CHUNK_FRAMES = 240 // 5 ms of audio per render block
        private const val VOICE_SLOTS = 16
    }
}
