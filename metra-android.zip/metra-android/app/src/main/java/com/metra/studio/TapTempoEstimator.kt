package com.metra.studio

import java.util.ArrayDeque
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/**
 * Robust tap-tempo estimator based on monotonic nanosecond timestamps.
 *
 * Accepted intervals are filtered against the recent median. A single long interval is treated
 * as a likely missed tap; two consecutive, similar outlier intervals are treated as an intentional
 * tempo change. This avoids both sudden half-tempo errors and permanently ignoring a new tempo.
 */
class TapTempoEstimator {
    private val intervals = ArrayDeque<Long>()
    private var previousTapNanos: Long? = null
    private var candidateIntervalNanos: Double? = null
    private var candidateCount = 0

    /** Returns a BPM estimate once at least two taps have been registered. */
    fun tap(timestampNanos: Long): Int? {
        val previous = previousTapNanos
        if (previous == null) {
            previousTapNanos = timestampNanos
            return null
        }

        val delta = timestampNanos - previous
        if (delta <= 0L) return null
        if (shouldResetForGap(timestampNanos)) {
            clearMeasurement()
            previousTapNanos = timestampNanos
            return null
        }
        // Ignore accidental double-taps without moving the reference timestamp.
        if (delta < MIN_INTERVAL_NANOS) return null

        previousTapNanos = timestampNanos
        if (intervals.isEmpty()) {
            intervals.addLast(delta)
            return estimateBpm()
        }

        val baseline = median(intervals.map { it.toDouble() })
        val tolerance = maxOf(MIN_OUTLIER_TOLERANCE_NANOS, baseline * OUTLIER_FRACTION)
        if (abs(delta.toDouble() - baseline) > tolerance) {
            registerTempoChangeCandidate(delta.toDouble())
            if (candidateCount >= REQUIRED_CONSISTENT_CANDIDATES) {
                val newInterval = candidateIntervalNanos ?: delta.toDouble()
                intervals.clear()
                intervals.addLast(newInterval.roundToLong().coerceAtLeast(1L))
                clearCandidate()
            }
            return estimateBpm()
        }

        // An interval consistent with the current tempo cancels a one-off outlier candidate.
        clearCandidate()
        intervals.addLast(delta)
        while (intervals.size > MAX_INTERVALS) intervals.removeFirst()
        return estimateBpm()
    }

    /** True when the pause is too long for the current tempo and a new tap sequence should begin. */
    fun shouldResetForGap(timestampNanos: Long): Boolean {
        val previous = previousTapNanos ?: return false
        val delta = timestampNanos - previous
        if (delta <= 0L) return false
        val baseline = intervals.takeIf { it.isNotEmpty() }
            ?.let { median(it.map(Long::toDouble)) } ?: 0.0
        val resetGap = maxOf(MIN_RESET_GAP_NANOS, baseline * RESET_GAP_INTERVAL_MULTIPLE)
        return delta.toDouble() > resetGap
    }

    fun reset() {
        clearMeasurement()
        previousTapNanos = null
    }

    private fun registerTempoChangeCandidate(interval: Double) {
        val candidate = candidateIntervalNanos
        val candidateTolerance = candidate?.let {
            maxOf(MIN_OUTLIER_TOLERANCE_NANOS, it * OUTLIER_FRACTION)
        }
        if (candidate != null && candidateTolerance != null && abs(interval - candidate) <= candidateTolerance) {
            candidateCount += 1
            candidateIntervalNanos = candidate + (interval - candidate) / candidateCount
        } else {
            candidateIntervalNanos = interval
            candidateCount = 1
        }
    }

    private fun estimateBpm(): Int? {
        if (intervals.isEmpty()) return null
        val sorted = intervals.map { it.toDouble() }.sorted()
        val center = median(sorted)
        val tolerance = maxOf(MIN_OUTLIER_TOLERANCE_NANOS, center * OUTLIER_FRACTION)
        val inliers = sorted.filter { abs(it - center) <= tolerance }
        val period = if (inliers.isEmpty()) center else inliers.average()
        if (period <= 0.0) return null
        return (60_000_000_000.0 / period).roundToInt().coerceIn(15, 500)
    }

    private fun clearCandidate() {
        candidateIntervalNanos = null
        candidateCount = 0
    }

    private fun clearMeasurement() {
        intervals.clear()
        clearCandidate()
    }

    private fun median(values: List<Double>): Double {
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 0) {
            (sorted[middle - 1] + sorted[middle]) / 2.0
        } else {
            sorted[middle]
        }
    }

    companion object {
        private const val MAX_INTERVALS = 9
        private const val MIN_INTERVAL_NANOS = 80_000_000L
        private const val MIN_RESET_GAP_NANOS = 6_000_000_000.0
        private const val RESET_GAP_INTERVAL_MULTIPLE = 2.5
        private const val MIN_OUTLIER_TOLERANCE_NANOS = 35_000_000.0
        private const val OUTLIER_FRACTION = 0.20
        private const val REQUIRED_CONSISTENT_CANDIDATES = 2
    }
}
