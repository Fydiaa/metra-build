package com.metra.studio

import java.util.ArrayDeque
import kotlin.math.abs
import kotlin.math.roundToInt

/** Robust tap-tempo estimator based on monotonic nanosecond timestamps. */
class TapTempoEstimator {
    private val intervals = ArrayDeque<Long>()
    private var previousTapNanos: Long? = null

    /** Returns a BPM estimate once at least two taps have been registered. */
    fun tap(timestampNanos: Long): Int? {
        val previous = previousTapNanos
        if (previous != null) {
            val delta = timestampNanos - previous
            if (delta <= 0L) return null
            if (delta > RESET_GAP_NANOS) {
                intervals.clear()
                previousTapNanos = timestampNanos
                return null
            }
            // Ignore impossible/accidental double-taps without poisoning the estimator.
            if (delta < MIN_INTERVAL_NANOS) return null
            intervals.addLast(delta)
            while (intervals.size > MAX_INTERVALS) intervals.removeFirst()
        }
        previousTapNanos = timestampNanos
        if (intervals.isEmpty()) return null

        val sorted = intervals.sorted()
        val median = if (sorted.size % 2 == 0) {
            (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0
        } else sorted[sorted.size / 2].toDouble()

        // Reject intervals that deviate substantially from the median, then average the rest.
        // This keeps ordinary human timing variation while limiting the effect of a missed tap.
        val tolerance = maxOf(MIN_OUTLIER_TOLERANCE_NANOS, median * OUTLIER_FRACTION)
        val inliers = sorted.filter { abs(it - median) <= tolerance }
        val selected: List<Double> = if (inliers.isEmpty()) listOf(median) else inliers.map { it.toDouble() }
        val meanInterval = selected.average()
        return (60_000_000_000.0 / meanInterval).roundToInt().coerceIn(15, 500)
    }

    fun reset() {
        intervals.clear()
        previousTapNanos = null
    }

    companion object {
        private const val MAX_INTERVALS = 9
        private const val MIN_INTERVAL_NANOS = 80_000_000L
        private const val RESET_GAP_NANOS = 6_000_000_000L
        private const val MIN_OUTLIER_TOLERANCE_NANOS = 35_000_000.0
        private const val OUTLIER_FRACTION = 0.20
    }
}
