package com.metra.studio

import androidx.compose.ui.graphics.Color

const val MIN_BPM = 15
const val MAX_BPM = 500

val SOUND_OPTIONS = listOf(
    SoundOption("wood", "Wood", "Caldo, legnoso"),
    SoundOption("deep", "Deep", "Corpo profondo"),
    SoundOption("classic", "Classic", "Secco, tradizionale"),
    SoundOption("block", "Block", "Nitido e presente"),
    SoundOption("soft", "Soft", "Morbido e rotondo")
)

data class SoundOption(val id: String, val title: String, val description: String)

data class NamedPreset(val name: String, val state: MetronomeUiState)

data class PaletteOption(
    val id: String,
    val title: String,
    val accent: Color,
    val accentDark: Color,
    val glow: Color
)

val PALETTES = listOf(
    PaletteOption("amber", "Amber", Color(0xFFF2B66D), Color(0xFF4A2D12), Color(0x33F2B66D)),
    PaletteOption("jade", "Jade", Color(0xFF83D6B0), Color(0xFF123A2B), Color(0x3383D6B0)),
    PaletteOption("violet", "Violet", Color(0xFFC4A7FF), Color(0xFF33204F), Color(0x33C4A7FF)),
    PaletteOption("ice", "Ice", Color(0xFF8BDDF2), Color(0xFF123746), Color(0x338BDDF2)),
    PaletteOption("coral", "Coral", Color(0xFFFF9B91), Color(0xFF4A201D), Color(0x33FF9B91))
)

/** Pattern values: 0 = normal, 1 = accent, 2 = mute. */
data class MetronomeUiState(
    val bpm: Int = 96,
    val numerator: Int = 4,
    val denominator: Int = 4,
    val subdivisions: Int = 1,
    val soundId: String = "wood",
    val paletteId: String = "amber",
    val muteAll: Boolean = false,
    val masterVolume: Float = 0.82f,
    val beatPattern: List<Int> = listOf(1, 0, 0, 0)
) {
    fun safePattern(): List<Int> = List(numerator.coerceIn(1, 16)) { index ->
        beatPattern.getOrNull(index)?.coerceIn(0, 2) ?: if (index == 0) 1 else 0
    }
}

data class AudioConfig(
    val bpm: Int,
    val beatsPerBar: Int,
    val subdivisions: Int,
    val soundId: String,
    val muteAll: Boolean,
    val beatPattern: IntArray,
    val masterVolume: Float = 0.82f
)

fun MetronomeUiState.toAudioConfig() = AudioConfig(
    bpm = bpm.coerceIn(MIN_BPM, MAX_BPM),
    beatsPerBar = numerator.coerceIn(1, 16),
    subdivisions = subdivisions.coerceIn(1, 4),
    soundId = soundId,
    muteAll = muteAll,
    beatPattern = safePattern().toIntArray(),
    masterVolume = masterVolume.coerceIn(0f, 1f)
)
