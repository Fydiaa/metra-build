package com.metra.studio.ui

import android.content.Context
import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.metra.studio.MAX_BPM
import com.metra.studio.MIN_BPM
import com.metra.studio.MetronomeUiState
import com.metra.studio.NamedPreset
import com.metra.studio.PALETTES
import com.metra.studio.SOUND_OPTIONS
import com.metra.studio.TapTempoEstimator
import com.metra.studio.audio.MetronomeAudioEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.min

private val ScreenBg = androidx.compose.ui.graphics.Color(0xFF101113)
private val CardBg = androidx.compose.ui.graphics.Color(0xFF17191C)
private val CardBgRaised = androidx.compose.ui.graphics.Color(0xFF1D2024)
private val MainText = androidx.compose.ui.graphics.Color(0xFFF3F0E9)
private val MutedText = androidx.compose.ui.graphics.Color(0xFF9B9DA3)

@Composable
fun MetraScreen(
    engine: MetronomeAudioEngine,
    currentBeat: Int,
    onCurrentBeatReset: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("metra-settings", Context.MODE_PRIVATE) }
    var state by remember { mutableStateOf(loadState(prefs)) }
    var isPlaying by rememberSaveable { mutableStateOf(false) }
    var showBpmDialog by remember { mutableStateOf(false) }
    var bpmDraft by remember { mutableStateOf("") }
    var showPresetDialog by remember { mutableStateOf(false) }
    var presetDraft by rememberSaveable { mutableStateOf("") }
    var presets by remember { mutableStateOf(loadPresets(prefs)) }
    var tapCount by remember { mutableIntStateOf(0) }
    var lastTapNanos by remember { mutableStateOf(0L) }
    var tapFeedback by remember { mutableStateOf("TAP TEMPO") }
    val tapTempo = remember { TapTempoEstimator() }
    val palette = PALETTES.firstOrNull { it.id == state.paletteId } ?: PALETTES.first()

    SideEffect { engine.updateConfig(state.toAudioConfig()) }
    LaunchedEffect(state) { saveState(prefs, state) }
    LaunchedEffect(presets) { savePresets(prefs, presets) }
    LaunchedEffect(isPlaying) {
        if (isPlaying) withContext(Dispatchers.IO) { engine.start() } else {
            withContext(Dispatchers.IO) { engine.stop() }
            onCurrentBeatReset()
        }
    }
    DisposableEffect(Unit) { onDispose { engine.stop() } }

    MetraTheme(palette) {
        Surface(color = ScreenBg, modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
                    .padding(top = 18.dp, bottom = 30.dp)
                    .windowInsetsPadding(WindowInsets.navigationBars),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Header(palette.title)

                TempoCard(
                    bpm = state.bpm,
                    numerator = state.numerator,
                    denominator = state.denominator,
                    currentBeat = currentBeat,
                    isPlaying = isPlaying,
                    pattern = state.safePattern(),
                    onEditBpm = { bpmDraft = state.bpm.toString(); showBpmDialog = true },
                    onBpmChange = { state = state.copy(bpm = it.coerceIn(MIN_BPM, MAX_BPM)) },
                    onPlay = { isPlaying = !isPlaying },
                    onTapTempo = {
                        val now = SystemClock.elapsedRealtimeNanos()
                        if (lastTapNanos > 0L && now - lastTapNanos > 6_000_000_000L) {
                            tapCount = 0
                            tapFeedback = "TAP TEMPO"
                            tapTempo.reset()
                        }
                        lastTapNanos = now
                        val estimated = tapTempo.tap(now)
                        tapCount = min(tapCount + 1, 10)
                        tapFeedback = if (estimated == null) "TAP TEMPO  ·  $tapCount" else "TAP TEMPO  ·  $tapCount  /  ${estimated} BPM"
                        if (estimated != null) state = state.copy(bpm = estimated)
                    },
                    tapFeedback = tapFeedback
                )

                PresetSection(
                    presets = presets,
                    onSave = { presetDraft = ""; showPresetDialog = true },
                    onLoad = { saved -> state = saved.state.copy(beatPattern = saved.state.safePattern()) },
                    onDelete = { name -> presets = presets.filterNot { it.name == name } }
                )

                MeterSection(
                    numerator = state.numerator,
                    denominator = state.denominator,
                    onSignature = { numerator, denominator ->
                        state = state.copy(
                            numerator = numerator,
                            denominator = denominator,
                            beatPattern = resizePattern(state.safePattern(), numerator)
                        )
                    },
                    onNumeratorChange = { n -> state = state.copy(numerator = n, beatPattern = resizePattern(state.safePattern(), n)) },
                    onDenominatorChange = { d -> state = state.copy(denominator = d) }
                )

                AccentSection(
                    numerator = state.numerator,
                    pattern = state.safePattern(),
                    currentBeat = currentBeat,
                    onPatternChange = { index, style ->
                        val updated = state.safePattern().toMutableList()
                        updated[index] = style
                        state = state.copy(beatPattern = updated)
                    }
                )

                SubdivisionSection(state.subdivisions) { state = state.copy(subdivisions = it) }
                SoundSection(
                    selectedId = state.soundId,
                    onSelect = { id -> state = state.copy(soundId = id); engine.preview(id) },
                    onPreview = { id -> engine.preview(id) }
                )
                VolumeSection(state.masterVolume) { state = state.copy(masterVolume = it) }
                PaletteSection(state.paletteId) { state = state.copy(paletteId = it) }
                MuteSection(state.muteAll) { state = state.copy(muteAll = it) }

                Text(
                    "AUDIO CLOCK  ·  SAMPLE-BASED",
                    modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.8.sp),
                    color = MutedText,
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    if (showBpmDialog) {
        AlertDialog(
            onDismissRequest = { showBpmDialog = false },
            containerColor = CardBgRaised,
            title = { Text("Imposta BPM", color = MainText, fontWeight = FontWeight.SemiBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Da $MIN_BPM a $MAX_BPM", color = MutedText, fontSize = 13.sp)
                    OutlinedTextField(
                        value = bpmDraft,
                        onValueChange = { text -> if (text.length <= 3 && text.all(Char::isDigit)) bpmDraft = text },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = TextStyle(color = MainText, fontSize = 24.sp, fontWeight = FontWeight.Bold),
                        label = { Text("BPM") }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    bpmDraft.toIntOrNull()?.let { state = state.copy(bpm = it.coerceIn(MIN_BPM, MAX_BPM)) }
                    showBpmDialog = false
                }) { Text("APPLICA", color = palette.accent) }
            },
            dismissButton = { TextButton(onClick = { showBpmDialog = false }) { Text("ANNULLA", color = MutedText) } }
        )
    }
    if (showPresetDialog) {
        AlertDialog(
            onDismissRequest = { showPresetDialog = false },
            containerColor = CardBgRaised,
            title = { Text("Salva preset", color = MainText, fontWeight = FontWeight.SemiBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Salva BPM, metrica, accenti, mute e timbro.", color = MutedText, fontSize = 13.sp)
                    OutlinedTextField(
                        value = presetDraft,
                        onValueChange = { presetDraft = it.take(28).replace("|", " ").replace("\n", " ").replace("\r", " ") },
                        singleLine = true,
                        textStyle = TextStyle(color = MainText, fontSize = 17.sp, fontWeight = FontWeight.Medium),
                        label = { Text("Nome del preset") }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val name = presetDraft.trim()
                    if (name.isNotEmpty()) {
                        val saved = NamedPreset(name, state.copy(beatPattern = state.safePattern()))
                        presets = (presets.filterNot { it.name.equals(name, ignoreCase = true) } + saved).takeLast(20)
                    }
                    showPresetDialog = false
                }) { Text("SALVA", color = MaterialTheme.colorScheme.primary) }
            },
            dismissButton = { TextButton(onClick = { showPresetDialog = false }) { Text("ANNULLA", color = MutedText) } }
        )
    }
}

@Composable
private fun Header(paletteName: String) {
    val accent = MaterialTheme.colorScheme.primary
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(15.dp)).background(CardBg),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(25.dp)) {
                val sw = 1.7.dp.toPx()
                drawCircle(accent, style = Stroke(sw))
                drawCircle(accent, radius = size.minDimension * .23f)
                drawLine(accent, Offset(size.width * .5f, size.height * .06f), Offset(size.width * .5f, size.height * .94f), sw, cap = StrokeCap.Round)
            }
        }
        Spacer(Modifier.width(11.dp))
        Column(verticalArrangement = Arrangement.spacedBy(1.dp), modifier = Modifier.weight(1f)) {
            Text("METRA", color = MainText, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 2.5.sp)
            Text("STUDIO METRONOME", color = MutedText, fontSize = 9.sp, letterSpacing = 2.sp)
        }
        Surface(
            color = CardBg,
            shape = RoundedCornerShape(50),
            modifier = Modifier
        ) {
            Row(Modifier.padding(horizontal = 11.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                Text(paletteName.uppercase(), fontSize = 10.sp, color = MainText, letterSpacing = 1.1.sp)
            }
        }
    }
}

@Composable
private fun TempoCard(
    bpm: Int,
    numerator: Int,
    denominator: Int,
    currentBeat: Int,
    isPlaying: Boolean,
    pattern: List<Int>,
    onEditBpm: () -> Unit,
    onBpmChange: (Int) -> Unit,
    onPlay: () -> Unit,
    onTapTempo: () -> Unit,
    tapFeedback: String
) {
    val accent = MaterialTheme.colorScheme.primary
    val pulse = remember { Animatable(1f) }
    LaunchedEffect(currentBeat, isPlaying) {
        if (isPlaying && currentBeat >= 0) {
            pulse.snapTo(1.035f)
            pulse.animateTo(1f, tween(durationMillis = 190, easing = FastOutSlowInEasing))
        } else pulse.snapTo(1f)
    }

    Surface(color = CardBg, shape = RoundedCornerShape(30.dp), modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("TEMPO", color = MutedText, fontSize = 10.sp, letterSpacing = 2.sp)
                    Text("${numerator}/${denominator}  TIME", color = MainText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
                Surface(color = if (isPlaying) accent.copy(alpha = .13f) else CardBgRaised, shape = RoundedCornerShape(50)) {
                    Text(
                        if (isPlaying) "RUNNING" else "READY",
                        color = if (isPlaying) accent else MutedText,
                        fontSize = 9.sp,
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp)
                    )
                }
            }

            Box(
                modifier = Modifier.size(184.dp).graphicsLayer { scaleX = pulse.value; scaleY = pulse.value }
                    .clickable(onClick = onEditBpm),
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 3.dp.toPx()
                    drawCircle(color = androidx.compose.ui.graphics.Color(0xFF2B2E32), style = Stroke(stroke), radius = size.minDimension * .43f)
                    drawArc(
                        color = accent.copy(alpha = if (isPlaying) .95f else .55f),
                        startAngle = -90f,
                        sweepAngle = if (isPlaying && currentBeat >= 0) 285f else 105f,
                        useCenter = false,
                        topLeft = Offset(size.width * .07f, size.height * .07f),
                        size = Size(size.width * .86f, size.height * .86f),
                        style = Stroke(stroke, cap = StrokeCap.Round)
                    )
                    for (i in 0 until numerator) {
                        val angle = Math.toRadians((-90.0 + i * 360.0 / numerator))
                        val r = size.minDimension * .49f
                        val point = Offset(size.width / 2 + kotlin.math.cos(angle).toFloat() * r, size.height / 2 + kotlin.math.sin(angle).toFloat() * r)
                        val isCurrent = isPlaying && currentBeat == i
                        val color = when {
                            pattern.getOrElse(i) { 0 } == 2 -> androidx.compose.ui.graphics.Color(0xFF5B5E63)
                            pattern.getOrElse(i) { 0 } == 1 -> accent
                            else -> accent.copy(alpha = .42f)
                        }
                        drawCircle(color, radius = if (isCurrent) 4.3.dp.toPx() else 2.8.dp.toPx(), center = point)
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy((-2).dp)) {
                    Text(bpm.toString(), color = MainText, fontSize = 59.sp, lineHeight = 64.sp, fontWeight = FontWeight.Light, letterSpacing = (-2.4).sp)
                    Text("BEATS / MIN", color = MutedText, fontSize = 9.sp, letterSpacing = 2.2.sp)
                    Text("TOCCA PER MODIFICARE", color = MutedText.copy(alpha = .72f), fontSize = 8.sp, letterSpacing = .6.sp)
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                RoundStepButton("−5", onClick = { onBpmChange(bpm - 5) }, modifier = Modifier.size(42.dp))
                RoundStepButton("−1", onClick = { onBpmChange(bpm - 1) }, modifier = Modifier.size(42.dp))
                Surface(
                    color = accent,
                    shape = CircleShape,
                    modifier = Modifier.size(68.dp).clickable(onClick = onPlay),
                    shadowElevation = if (isPlaying) 0.dp else 6.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (isPlaying) "Pausa" else "Avvia metronomo",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(33.dp)
                        )
                    }
                }
                RoundStepButton("+1", onClick = { onBpmChange(bpm + 1) }, modifier = Modifier.size(42.dp))
                RoundStepButton("+5", onClick = { onBpmChange(bpm + 5) }, modifier = Modifier.size(42.dp))
            }

            Slider(
                value = bpm.toFloat(),
                onValueChange = { onBpmChange(it.toInt().coerceIn(MIN_BPM, MAX_BPM)) },
                valueRange = MIN_BPM.toFloat()..MAX_BPM.toFloat(),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp).height(24.dp),
                colors = SliderDefaults.colors(
                    thumbColor = accent,
                    activeTrackColor = accent,
                    inactiveTrackColor = androidx.compose.ui.graphics.Color(0xFF383B40)
                )
            )

            Button(
                onClick = onTapTempo,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = CardBgRaised, contentColor = accent)
            ) {
                Icon(Icons.Rounded.TouchApp, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(tapFeedback, fontSize = 11.sp, letterSpacing = 1.1.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun RoundStepButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(color = CardBgRaised, shape = CircleShape, modifier = modifier.clickable(onClick = onClick)) {
        Box(contentAlignment = Alignment.Center) {
            Text(label, color = MainText, fontSize = if (label.length > 2) 11.sp else 14.sp, fontWeight = FontWeight.Medium)
        }
    }
}


@Composable
private fun PresetSection(
    presets: List<NamedPreset>,
    onSave: () -> Unit,
    onLoad: (NamedPreset) -> Unit,
    onDelete: (String) -> Unit
) {
    SectionHeader("PRESETS", "${presets.size} SALVATI")
    Surface(color = CardBg, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                if (presets.isEmpty()) "Salva un set con nome per richiamare BPM, metrica, accenti e suono." else "Tocca un preset per richiamare la configurazione.",
                color = MutedText, fontSize = 12.sp, lineHeight = 17.sp
            )
            if (presets.isNotEmpty()) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    presets.forEach { preset ->
                        Surface(color = CardBgRaised, shape = RoundedCornerShape(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(
                                    modifier = Modifier.clickable { onLoad(preset) }.padding(start = 12.dp, top = 9.dp, bottom = 9.dp),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Text(preset.name, color = MainText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                    Text("${preset.state.bpm} BPM · ${preset.state.numerator}/${preset.state.denominator}", color = MutedText, fontSize = 9.sp)
                                }
                                IconButton(onClick = { onDelete(preset.name) }, modifier = Modifier.size(34.dp)) {
                                    Icon(Icons.Rounded.Close, contentDescription = "Elimina ${preset.name}", tint = MutedText, modifier = Modifier.size(15.dp))
                                }
                            }
                        }
                    }
                }
            }
            Button(
                onClick = onSave,
                modifier = Modifier.fillMaxWidth().height(43.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = CardBgRaised, contentColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(7.dp))
                Text("SALVA SET ATTUALE", fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun MeterSection(
    numerator: Int,
    denominator: Int,
    onSignature: (Int, Int) -> Unit,
    onNumeratorChange: (Int) -> Unit,
    onDenominatorChange: (Int) -> Unit
) {
    SectionHeader("TIME SIGNATURE", "${numerator}/${denominator}")
    Surface(color = CardBg, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(2 to 4, 3 to 4, 4 to 4, 5 to 4, 6 to 8, 7 to 8, 9 to 8, 12 to 8).forEach { (n, d) ->
                    SelectPill("$n/$d", selected = numerator == n && denominator == d) { onSignature(n, d) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Battiti per battuta", color = MainText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text("Personalizza il numeratore", color = MutedText, fontSize = 11.sp)
                }
                SmallStepper(value = numerator, min = 1, max = 16, onChange = onNumeratorChange)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Unità di tempo", color = MainText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text("Denominatore", color = MutedText, fontSize = 11.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(2, 4, 8, 16).forEach { d -> SelectPill("$d", selected = denominator == d, compact = true) { onDenominatorChange(d) } }
                }
            }
        }
    }
}

@Composable
private fun AccentSection(numerator: Int, pattern: List<Int>, currentBeat: Int, onPatternChange: (Int, Int) -> Unit) {
    SectionHeader("ACCENTS & MUTE", "${pattern.count { it == 1 }} ACCENTI")
    Surface(color = CardBg, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Tocca ogni battito per cambiare stato: normale → accento → mute.", color = MutedText, fontSize = 12.sp, lineHeight = 17.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(numerator) { index ->
                    val style = pattern.getOrElse(index) { if (index == 0) 1 else 0 }
                    val accent = MaterialTheme.colorScheme.primary
                    val selectedColor = when (style) {
                        1 -> accent.copy(alpha = .18f)
                        2 -> androidx.compose.ui.graphics.Color(0xFF282A2E)
                        else -> CardBgRaised
                    }
                    val borderColor = if (currentBeat == index) accent else if (style == 1) accent.copy(alpha = .62f) else androidx.compose.ui.graphics.Color(0xFF34373C)
                    Surface(
                        color = selectedColor,
                        shape = RoundedCornerShape(15.dp),
                        modifier = Modifier.width(43.dp).height(61.dp).border(1.dp, borderColor, RoundedCornerShape(15.dp))
                            .clickable { onPatternChange(index, (style + 1) % 3) }
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center, modifier = Modifier.fillMaxSize()) {
                            Text("${index + 1}", color = if (style == 2) MutedText else MainText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(3.dp))
                            Text(when (style) { 1 -> "A"; 2 -> "×"; else -> "·" }, color = if (style == 1) accent else MutedText, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                LegendDot(MaterialTheme.colorScheme.primary, "Accento")
                LegendDot(MutedText, "Normale")
                LegendDot(androidx.compose.ui.graphics.Color(0xFF5B5E63), "Mute")
            }
        }
    }
}

@Composable
private fun SubdivisionSection(selected: Int, onChange: (Int) -> Unit) {
    SectionHeader("SUBDIVISION", "${selected}×")
    Surface(color = CardBg, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Suddivisioni sincronizzate al clock audio.", color = MutedText, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf(1 to "Beat", 2 to "Ottavi", 3 to "Terzine", 4 to "Sedicesimi").forEach { (count, title) ->
                    Surface(
                        color = if (selected == count) MaterialTheme.colorScheme.primary.copy(alpha = .15f) else CardBgRaised,
                        shape = RoundedCornerShape(13.dp),
                        modifier = Modifier.weight(1f).height(57.dp)
                            .border(1.dp, if (selected == count) MaterialTheme.colorScheme.primary.copy(alpha = .6f) else androidx.compose.ui.graphics.Color.Transparent, RoundedCornerShape(13.dp))
                            .clickable { onChange(count) }
                    ) {
                        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Text("${count}×", color = if (selected == count) MaterialTheme.colorScheme.primary else MainText, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(title, color = MutedText, fontSize = 9.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SoundSection(selectedId: String, onSelect: (String) -> Unit, onPreview: (String) -> Unit) {
    SectionHeader("SOUND", SOUND_OPTIONS.firstOrNull { it.id == selectedId }?.title?.uppercase() ?: "WOOD")
    Surface(color = CardBg, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Tocca un timbro per selezionarlo e ascoltarlo.", color = MutedText, fontSize = 12.sp)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SOUND_OPTIONS.chunked(2).forEach { rowOptions ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        rowOptions.forEach { option ->
                            val isSelected = selectedId == option.id
                            Surface(
                                color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = .12f) else CardBgRaised,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.weight(1f).border(
                                    1.dp,
                                    if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = .65f) else androidx.compose.ui.graphics.Color.Transparent,
                                    RoundedCornerShape(16.dp)
                                ).clickable { onSelect(option.id) }
                            ) {
                                Row(Modifier.padding(horizontal = 11.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(32.dp).clip(RoundedCornerShape(11.dp)).background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = .16f) else CardBg)) {
                                        Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = if (isSelected) MaterialTheme.colorScheme.primary else MutedText, modifier = Modifier.align(Alignment.Center).size(18.dp))
                                    }
                                    Spacer(Modifier.width(9.dp))
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(option.title, color = MainText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                        Text(option.description, color = MutedText, fontSize = 9.sp, maxLines = 2, lineHeight = 11.sp)
                                    }
                                    if (isSelected) Icon(Icons.Rounded.Check, contentDescription = "Selezionato", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                                }
                            }
                        }
                        if (rowOptions.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
            // One-tap preview remains available after selecting another row or while playing.
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButtonLike("▶  ASCOLTA ${SOUND_OPTIONS.firstOrNull { it.id == selectedId }?.title?.uppercase() ?: "WOOD"}") { onPreview(selectedId) }
            }
        }
    }
}


@Composable
private fun VolumeSection(volume: Float, onChange: (Float) -> Unit) {
    SectionHeader("OUTPUT LEVEL", "${(volume * 100).toInt()}%")
    Surface(color = CardBg, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 17.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Volume master", color = MainText, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                Text("${(volume * 100).toInt()}%", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = volume,
                onValueChange = onChange,
                valueRange = 0f..1f,
                colors = SliderDefaults.colors(
                    thumbColor = MaterialTheme.colorScheme.primary,
                    activeTrackColor = MaterialTheme.colorScheme.primary,
                    inactiveTrackColor = androidx.compose.ui.graphics.Color(0xFF383B40)
                )
            )
        }
    }
}

@Composable
private fun PaletteSection(selectedId: String, onChange: (String) -> Unit) {
    SectionHeader("COLOR PALETTE", PALETTES.firstOrNull { it.id == selectedId }?.title?.uppercase() ?: "AMBER")
    Surface(color = CardBg, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PALETTES.forEach { palette ->
                val selected = selectedId == palette.id
                Column(
                    modifier = Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).clickable { onChange(palette.id) }.padding(vertical = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Box(
                        modifier = Modifier.size(if (selected) 40.dp else 35.dp).clip(CircleShape)
                            .background(palette.accent.copy(alpha = .16f))
                            .border(if (selected) 2.dp else 1.dp, palette.accent.copy(alpha = if (selected) 1f else .55f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.size(14.dp).clip(CircleShape).background(palette.accent))
                    }
                    Text(palette.title, color = if (selected) MainText else MutedText, fontSize = 10.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
private fun MuteSection(muted: Boolean, onChange: (Boolean) -> Unit) {
    Surface(color = CardBg, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 17.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(39.dp).clip(RoundedCornerShape(13.dp)).background(CardBgRaised), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.VolumeOff, contentDescription = null, tint = if (muted) MaterialTheme.colorScheme.primary else MutedText)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Mute audio", color = MainText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text("Il clock continua, i suoni sono disattivati", color = MutedText, fontSize = 11.sp)
            }
            Switch(checked = muted, onCheckedChange = onChange)
        }
    }
}

@Composable
private fun SectionHeader(title: String, trailing: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = MutedText, fontSize = 10.sp, letterSpacing = 1.9.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(trailing, color = MaterialTheme.colorScheme.primary, fontSize = 10.sp, letterSpacing = 1.1.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SelectPill(text: String, selected: Boolean, compact: Boolean = false, onClick: () -> Unit) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = .16f) else CardBgRaised,
        shape = RoundedCornerShape(50),
        modifier = Modifier.height(if (compact) 36.dp else 39.dp)
            .border(1.dp, if (selected) MaterialTheme.colorScheme.primary.copy(alpha = .65f) else androidx.compose.ui.graphics.Color.Transparent, RoundedCornerShape(50))
            .clickable(onClick = onClick)
    ) {
        Box(Modifier.padding(horizontal = if (compact) 12.dp else 15.dp), contentAlignment = Alignment.Center) {
            Text(text, color = if (selected) MaterialTheme.colorScheme.primary else MainText, fontSize = 12.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
        }
    }
}

@Composable
private fun SmallStepper(value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        IconButton(onClick = { onChange((value - 1).coerceAtLeast(min)) }, modifier = Modifier.size(34.dp)) {
            Icon(Icons.Rounded.Remove, contentDescription = "Diminuisci", tint = MutedText, modifier = Modifier.size(18.dp))
        }
        Text(value.toString(), color = MainText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.width(24.dp))
        IconButton(onClick = { onChange((value + 1).coerceAtMost(max)) }, modifier = Modifier.size(34.dp)) {
            Icon(Icons.Rounded.Add, contentDescription = "Aumenta", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun LegendDot(color: androidx.compose.ui.graphics.Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(color))
        Text(label, color = MutedText, fontSize = 10.sp)
    }
}

@Composable
private fun TextButtonLike(text: String, onClick: () -> Unit) {
    Text(text, modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 7.dp), color = MaterialTheme.colorScheme.primary, fontSize = 10.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Bold)
}

private fun resizePattern(existing: List<Int>, newSize: Int): List<Int> = List(newSize.coerceIn(1, 16)) { index ->
    existing.getOrNull(index) ?: if (index == 0) 1 else 0
}


private fun loadPresets(prefs: android.content.SharedPreferences): List<NamedPreset> {
    val encoded = prefs.getString("presets", "") ?: return emptyList()
    return encoded.lineSequence().mapNotNull { line ->
        val fields = line.split("|")
        if (fields.size != 10 || fields[0].isBlank()) return@mapNotNull null
        val bpm = fields[1].toIntOrNull()?.coerceIn(MIN_BPM, MAX_BPM) ?: return@mapNotNull null
        val numerator = fields[2].toIntOrNull()?.coerceIn(1, 16) ?: return@mapNotNull null
        val denominator = fields[3].toIntOrNull()?.takeIf { it in listOf(2, 4, 8, 16) } ?: 4
        val subdivisions = fields[4].toIntOrNull()?.coerceIn(1, 4) ?: 1
        val soundId = fields[5].takeIf { value -> SOUND_OPTIONS.any { it.id == value } } ?: "wood"
        val paletteId = fields[6].takeIf { value -> PALETTES.any { it.id == value } } ?: "amber"
        val mute = fields[7].toBooleanStrictOrNull() ?: false
        val volume = fields[8].toFloatOrNull()?.coerceIn(0f, 1f) ?: 0.82f
        val pattern = fields[9].split(",").mapNotNull { it.toIntOrNull()?.coerceIn(0, 2) }
        val presetState = MetronomeUiState(
            bpm = bpm,
            numerator = numerator,
            denominator = denominator,
            subdivisions = subdivisions,
            soundId = soundId,
            paletteId = paletteId,
            muteAll = mute,
            masterVolume = volume,
            beatPattern = resizePattern(pattern, numerator)
        )
        NamedPreset(fields[0], presetState)
    }.takeLast(20).toList()
}

private fun savePresets(prefs: android.content.SharedPreferences, presets: List<NamedPreset>) {
    val encoded = presets.takeLast(20).joinToString("\n") { preset ->
        val safeName = preset.name.trim().replace("|", " ").replace("\n", " ").replace("\r", " ")
        val state = preset.state
        listOf(
            safeName,
            state.bpm,
            state.numerator,
            state.denominator,
            state.subdivisions,
            state.soundId,
            state.paletteId,
            state.muteAll,
            state.masterVolume,
            state.safePattern().joinToString(",")
        ).joinToString("|")
    }
    prefs.edit().putString("presets", encoded).apply()
}

private fun loadState(prefs: android.content.SharedPreferences): MetronomeUiState {
    val numerator = prefs.getInt("numerator", 4).coerceIn(1, 16)
    val pattern = prefs.getString("pattern", "1,0,0,0")?.split(",")?.mapNotNull { it.toIntOrNull()?.coerceIn(0, 2) } ?: listOf(1, 0, 0, 0)
    return MetronomeUiState(
        bpm = prefs.getInt("bpm", 96).coerceIn(MIN_BPM, MAX_BPM),
        numerator = numerator,
        denominator = prefs.getInt("denominator", 4).let { if (it in listOf(2, 4, 8, 16)) it else 4 },
        subdivisions = prefs.getInt("subdivisions", 1).coerceIn(1, 4),
        soundId = prefs.getString("soundId", "wood")?.takeIf { it in SOUND_OPTIONS.map { opt -> opt.id } } ?: "wood",
        paletteId = prefs.getString("paletteId", "amber")?.takeIf { id -> PALETTES.any { it.id == id } } ?: "amber",
        muteAll = prefs.getBoolean("muteAll", false),
        masterVolume = prefs.getFloat("masterVolume", 0.82f).coerceIn(0f, 1f),
        beatPattern = resizePattern(pattern, numerator)
    )
}

private fun saveState(prefs: android.content.SharedPreferences, state: MetronomeUiState) {
    prefs.edit()
        .putInt("bpm", state.bpm)
        .putInt("numerator", state.numerator)
        .putInt("denominator", state.denominator)
        .putInt("subdivisions", state.subdivisions)
        .putString("soundId", state.soundId)
        .putString("paletteId", state.paletteId)
        .putBoolean("muteAll", state.muteAll)
        .putFloat("masterVolume", state.masterVolume)
        .putString("pattern", state.safePattern().joinToString(","))
        .apply()
}
