package com.metra.studio.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.metra.studio.PaletteOption

private val Background = Color(0xFF101113)
private val SurfaceLow = Color(0xFF17191C)
private val SurfaceMid = Color(0xFF1D2024)
private val TextPrimary = Color(0xFFF3F0E9)
private val TextMuted = Color(0xFF9B9DA3)

@Composable
fun MetraTheme(palette: PaletteOption, content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = palette.accent,
        onPrimary = Color(0xFF191714),
        primaryContainer = palette.accentDark,
        onPrimaryContainer = palette.accent,
        secondary = palette.accent,
        onSecondary = Color(0xFF191714),
        tertiary = palette.accent,
        background = Background,
        onBackground = TextPrimary,
        surface = SurfaceLow,
        onSurface = TextPrimary,
        surfaceVariant = SurfaceMid,
        onSurfaceVariant = TextMuted,
        outline = Color(0xFF35383D),
        outlineVariant = Color(0xFF292C30)
    )
    MaterialTheme(colorScheme = colors, content = content)
}
