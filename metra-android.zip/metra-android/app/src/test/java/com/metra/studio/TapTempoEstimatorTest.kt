package com.metra.studio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TapTempoEstimatorTest {
    @Test fun estimatesStable120Bpm() {
        val estimator = TapTempoEstimator()
        assertNull(estimator.tap(0L))
        assertEquals(120, estimator.tap(500_000_000L))
        assertEquals(120, estimator.tap(1_000_000_000L))
        assertEquals(120, estimator.tap(1_500_000_000L))
    }

    @Test fun rejectsSingleMissedOrLateTapAsOutlier() {
        val estimator = TapTempoEstimator()
        estimator.tap(0L)
        estimator.tap(500_000_000L)
        estimator.tap(1_010_000_000L)
        estimator.tap(1_500_000_000L)
        assertEquals(120, estimator.tap(2_500_000_000L))
        assertEquals(120, estimator.tap(3_000_000_000L))
    }

    @Test fun oneMissedTapWithShortHistoryDoesNotCutTempoInHalf() {
        val estimator = TapTempoEstimator()
        estimator.tap(0L)
        assertEquals(120, estimator.tap(500_000_000L))
        assertEquals(120, estimator.tap(2_000_000_000L)) // a single missed beat
        assertEquals(120, estimator.tap(2_500_000_000L))
    }

    @Test fun consistentNewTempoIsAcceptedAfterTwoIntervals() {
        val estimator = TapTempoEstimator()
        estimator.tap(0L)
        assertEquals(120, estimator.tap(500_000_000L))
        assertEquals(120, estimator.tap(1_500_000_000L))
        assertEquals(60, estimator.tap(2_500_000_000L))
        assertEquals(60, estimator.tap(3_500_000_000L))
    }

    @Test fun ignoresTooFastTapWithoutPoisoningNextInterval() {
        val estimator = TapTempoEstimator()
        estimator.tap(0L)
        assertEquals(120, estimator.tap(500_000_000L))
        assertNull(estimator.tap(550_000_000L))
        assertEquals(120, estimator.tap(1_000_000_000L))
    }

    @Test fun nonMonotonicTimestampDoesNotPoisonMeasurement() {
        val estimator = TapTempoEstimator()
        estimator.tap(0L)
        assertEquals(120, estimator.tap(500_000_000L))
        assertNull(estimator.tap(400_000_000L))
        assertEquals(120, estimator.tap(1_000_000_000L))
    }

    @Test fun clampsToSupportedTempoRange() {
        val estimator = TapTempoEstimator()
        estimator.tap(0L)
        assertEquals(500, estimator.tap(80_000_000L))
        estimator.reset()
        estimator.tap(10_000_000_000L)
        assertEquals(15, estimator.tap(14_500_000_000L))
    }

    @Test fun slowestSupportedTempoSurvivesOneMissedBeat() {
        val estimator = TapTempoEstimator()
        estimator.tap(0L)
        assertEquals(15, estimator.tap(4_000_000_000L))
        assertEquals(15, estimator.tap(12_000_000_000L)) // one missed tap at 15 BPM
        assertEquals(15, estimator.tap(16_000_000_000L))
    }

    @Test fun aLongPauseStartsANewMeasurement() {
        val estimator = TapTempoEstimator()
        estimator.tap(0L)
        assertEquals(120, estimator.tap(500_000_000L))
        assertNull(estimator.tap(7_000_000_000L))
    }
}
